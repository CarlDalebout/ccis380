// File  : Keyboard.h
// Author: smaug

#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <list>

namespace mygllib
{
    class Keyboard
    {
    public:
        static void keyboard(unsigned char key, int w, int h);
    };

    class KeyboardBase
    {
    };
}

#endif
