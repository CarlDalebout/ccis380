// File  : Reshape.h
// Author: smaug

#ifndef RESHAPE_H
#define RESHAPE_H

namespace mygllib
{
    class Reshape
    {
    public:
        static void reshape(int w, int h);
    };
}

#endif
