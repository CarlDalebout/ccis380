#include "View.h"

namespace mygllib
{
    extern View view;
};
