#include <iostream>
#include <cmath>

#include <GL/freeglut.h>
#include "gl3d.h"
#inlcude "myglm.h"
